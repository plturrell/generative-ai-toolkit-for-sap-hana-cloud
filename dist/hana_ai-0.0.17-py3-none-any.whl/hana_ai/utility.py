"""
Utility functions for counting tokens in a query.
"""

import json
from gen_ai_hub import GenAIHubProxyClient
import nltk
import requests
from gen_ai_hub.proxy.core.proxy_clients import get_proxy_client

def count_tokens(query):
    """
    Counts the number of tokens in the given query.

    Parameters:
    query (str): The input query.

    Returns:
    int: The number of tokens in the query.
    """
    return len(nltk.word_tokenize(query))

def get_btp_proxy_token(key_file):
    with open(key_file, "r") as key_file:
        svc_key = json.load(key_file)
    client_id = svc_key["uaa"]["clientid"]
    client_secret = svc_key["uaa"]["clientsecret"]
    uaa_url = svc_key["uaa"]["url"]
    params = {"grant_type": "client_credentials" }
    resp = requests.post(f"{uaa_url}/oauth/token",
                        auth=(client_id, client_secret),
                        params=params)
    return resp.json()["access_token"], svc_key["url"]

def get_gen_ai_hub_token(key_file):
    with open(key_file, "r") as key_file:
        svc_key = json.load(key_file)
    base_url = svc_key["serviceurls"]["AI_API_URL"]
    client_id = svc_key["clientid"]
    client_secret = svc_key["clientsecret"]
    uaa_url = svc_key["url"] + "/oauth/token"
    client = GenAIHubProxyClient(
        base_url=base_url,
        auth_url=uaa_url,
        client_id=client_id,
        client_secret=client_secret
    )
    return client.get_ai_core_token()

### temporary fix for enabling gpt4o
def enable_gpt4o():
    from gen_ai_hub.proxy.gen_ai_hub_proxy.client import Deployment, OPEN_AI_CHAT_COMPLETION
    if 'gpt-4o' not in Deployment.prediction_urls._suffixes:
        Deployment.prediction_urls.register({'gpt-4o': OPEN_AI_CHAT_COMPLETION})
    try:
        import langchain as _
    except ImportError:
        pass
    else:
        from gen_ai_hub.proxy.langchain.init_models import catalog, ModelType
        from gen_ai_hub.proxy.langchain.openai import init_chat_model, ChatOpenAI
        if 'gpt-4o' not in catalog.all_llms():
            catalog.register('gen-ai-hub', ChatOpenAI, 'gpt-4o')(init_chat_model)
