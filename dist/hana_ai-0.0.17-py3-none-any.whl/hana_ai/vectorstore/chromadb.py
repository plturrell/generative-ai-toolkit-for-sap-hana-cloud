"""
Chromadb to save and get embeddings.
"""
import logging

import chromadb
from chromadb.api import ClientAPI
from chromadb.api.models.Collection import Collection
import chromadb.utils.embedding_functions as ef


#pylint: disable=redefined-builtin

logger = logging.getLogger(__name__) #pylint: disable=invalid-name

class HANAMLinChromadb(object):
    """
    Chromadb to save and get embeddings.
    """
    path: str
    client: ClientAPI
    collection_name: str
    collection: Collection
    def __init__(self, path, collection_name, embedding_function=ef.DefaultEmbeddingFunction()):
        """
        Init chromadb.

        Parameters:
        -----------
        path: str
            Path to save vectordb.
        collection_name: str
            Vectordb name.
        embedding_function: EmbeddingFunction
            Embedding function.
        """
        self.path = path
        self.client = chromadb.PersistentClient(path=path)
        self.collection_name = collection_name
        self.embedding_function = embedding_function
        self.create_collection()

    def get_client(self):
        """
        Get chromadb client.
        """
        return self.client

    def get_collection(self):
        """
        Get collection.
        """
        return self.collection

    def create_collection(self):
        """
        Create collection.
        """
        self.collection = self.client.get_or_create_collection(name=self.collection_name, embedding_function=self.embedding_function)

    def delete_collection(self):
        """
        Delete collection.
        """
        try:
            self.client.delete_collection(self.collection_name)
        except Exception as err:
            logger.error(err)
            pass

    def _convert_list_to_dict(self, mylist):
        """
        Convert list to dict.
        """
        return [{"source": mylist[i]} for i in range(0, len(mylist))]

    def upsert_knowledge(self, knowledge, key='id', description='description', example='example', force=False):
        """
        Upsert knowledge to vectordb.

        Parameters:
        -----------
        knowledge: dict
            Knowledge.
        key: str
            Key.
        description: str
            Description.
        example: str
            Example.
        force: bool
            Force.
        """
        if force:
            self.delete_collection()
            self.create_collection()
        self.collection.upsert(ids=knowledge[key], documents=knowledge[description], metadatas=self._convert_list_to_dict(knowledge[example]))

    def query(self, input, top_n=1):
        """
        Query vectordb.

        Parameters:
        -----------
        input: str
            Input.
        top_n: int
            Top n.
        """
        results = self.collection.query(query_texts=input, n_results=top_n)
        return results
