"""
Chromadb to save and get embeddings.
"""

#pylint: disable=no-name-in-module
#pylint: disable=redefined-builtin

import os
import logging

from concurrent.futures import ThreadPoolExecutor, as_completed
from tqdm import tqdm
import pandas as pd

from langchain.prompts import ChatPromptTemplate
from langchain.chains import LLMChain

from hana_ml import ConnectionContext, dataframe
from hana_ai.vectorstore.embedding_service import BTPProxyEmbeddingService

logger = logging.getLogger(__name__) #pylint: disable=invalid-name

def extract_entity_relation_by_llm(query, llm):
    """
    Extract entity and relation by llm.

    Parameters
    ----------
    query: str
        Query.
    llm: any
        Language model.

    Returns
    -------
    entity: str
        Entity.
    relation: str
        Relation.
    """
    prompt = ChatPromptTemplate.from_template(
    "Get the entity and the relation of the following content in the format of <entity>|<relation>. The entity is the algorithm/model while the relation is how we use it. {content}"
)

    chain = LLMChain(llm=llm, prompt=prompt)
    answer = chain.invoke(query)
    return answer.split('|')[0], answer.split('|')[1]

def _escape_reserved_words(sentence, escape_reserved_words=False):
    if not escape_reserved_words:
        return sentence
    file_dir = os.path.join(os.path.dirname(__file__), "reserved_words.txt")
    reserved_words = None
    with open(file_dir, 'r') as f:
        reserved_words = list(map(str.strip, f.readlines()))
    for reserved_word in reserved_words:
        if reserved_word in sentence:
            sentence = sentence.replace(" " + reserved_word + " ", " _" + reserved_word + "_ ")
    sentence = sentence.replace(";", "").replace("'", "''")
    return sentence

def _par_embeddings(model, knowledges, escape_reserved_words=False):
    if isinstance(knowledges[0], list):
        emb_list = model(knowledges[1])
        result = []
        for idx in range(0, len(knowledges[0])):
            result.append((knowledges[0][idx],
                           _escape_reserved_words(knowledges[1][idx], escape_reserved_words),
                           _escape_reserved_words(knowledges[2][idx], escape_reserved_words),
                           str(emb_list[idx])))
        return result
    return (knowledges[0], _escape_reserved_words(knowledges[1], escape_reserved_words), _escape_reserved_words(knowledges[2], escape_reserved_words), str(model(knowledges[1])[0]))

def _par_embeddings2(model, knowledges, escape_reserved_words=False):
    if isinstance(knowledges[0], list):
        emb_list0 = model(knowledges[0])
        emb_list1 = model(knowledges[1])
        result = []
        for idx in range(0, len(knowledges[0])):
            result.append((knowledges[0][idx],
                           _escape_reserved_words(knowledges[1][idx], escape_reserved_words),
                           _escape_reserved_words(knowledges[2][idx], escape_reserved_words),
                           str(emb_list0[idx]),
                           str(emb_list1[idx])))
        return result
    return (knowledges[0], _escape_reserved_words(knowledges[1], escape_reserved_words), _escape_reserved_words(knowledges[2], escape_reserved_words), str(model(knowledges[0])[0]), str(model(knowledges[1])[0]))

class HANAMLinVectorEngine(object):
    """
    HANA vector engine.

    Parameters:
    -----------
    path: str
        Path to save vectordb.
    collection_name: str
        Vectordb name.
    embedding_function: EmbeddingFunction
        Embedding function.
    threads: int, optional
        Number of threads from the client side to call the embedding service.
    upload_chunksize: int, optional
        Number of chunks for the database bulk insertion.
    embeddings_batchsize: int, optional
        Define the batchsize for each embedding service call.
    """
    connection_context: ConnectionContext = None
    table_name: str = None
    embedding_function: any = None
    schema: str = None
    threads: int = None
    vector_length: int = None
    upload_chunksize: int = None
    embedding_batchsize: int = None
    columns: list = None
    def __init__(self, connection_context, table_name, embedding_function=None, schema=None, threads=None, upload_chunksize=50000, embedding_batchsize=None):
        self.connection_context = connection_context
        self.table_name = table_name
        self.schema = schema
        self.embedding_function = embedding_function
        if self.embedding_function is None:
            self.embedding_function = BTPProxyEmbeddingService()
        self.threads = threads
        self.upload_chunksize = upload_chunksize
        self.embedding_batchsize = embedding_batchsize
        self.current_query_distance = None
        self.current_query_rows = None

    def get_knowledge(self):
        """
        Get knowledge dataframe.
        """
        return self.connection_context.table(table=self.table_name, schema=self.schema)

    def create_embeddings(self,
                          knowledge,
                          key='id',
                          description='description',
                          example='example',
                          escape_reserved_words=False):
        """
        Create embeddings.

        Parameters
        ----------
        knowledge: dict or pd.DataFrame
            Knowledge data.
        key: str, optional
            Key column name.
        description: str, optional
            Description column name.
        example: str, optional
            Example column name.
        """
        model = self.embedding_function
        if isinstance(knowledge, pd.DataFrame):
            knowledge = knowledge.to_dict('series')
        knowledges = []
        knowledge_key = list(knowledge[key])
        knowledge_description = list(knowledge[description])
        knowledge_example = list(knowledge[example])
        t = tqdm(total=len(knowledge_key))
        if self.embedding_batchsize:
            if isinstance(self.threads, int):
                pool = ThreadPoolExecutor(self.threads)
                futures = []
                for chunk in range(0, len(knowledge_key), self.embedding_batchsize):
                    futures.append(pool.submit(_par_embeddings, model, (knowledge_key[chunk:chunk+self.embedding_batchsize], knowledge_description[chunk:chunk+self.embedding_batchsize], knowledge_example[chunk:chunk+self.embedding_batchsize]), escape_reserved_words))
                for x in as_completed(futures):
                    result = x.result()
                    knowledges = knowledges + result
                    t.update(len(result))
                pool.shutdown()
            else:
                for chunk in range(0, len(knowledge_key), self.embedding_batchsize):
                    result = _par_embeddings(model, (knowledge_key[chunk:chunk+self.embedding_batchsize],
                                                     knowledge_description[chunk:chunk+self.embedding_batchsize],
                                                     knowledge_example[chunk:chunk+self.embedding_batchsize]), escape_reserved_words)
                    knowledges = knowledges + result
                    t.update(len(result))
        else:
            if isinstance(self.threads, int):
                pool = ThreadPoolExecutor(self.threads)
                futures = []
                for kkey, desc, exmp in zip(knowledge_key, knowledge_description, knowledge_example):
                    futures.append(pool.submit(_par_embeddings, model, (kkey, desc, exmp), escape_reserved_words))
                for x in as_completed(futures):
                    knowledges.append(x.result())
                    t.update(1)
                pool.shutdown()
            else:
                for kkey, desc, exmp in zip(knowledge_key, knowledge_description, knowledge_example):
                    emb_vec = model(desc)
                    knowledges.append((kkey, _escape_reserved_words(desc, escape_reserved_words), _escape_reserved_words(exmp, escape_reserved_words), str(emb_vec[0])))
                    t.update(1)
        t.close()
        if self.vector_length is None:
            self.vector_length = len(eval(knowledges[0][3]))
        description_ = description
        if description == example:
            description_ = description + "_0"
        return pd.DataFrame(knowledges, columns=[key, description_, example, "embeddings"])

    def upsert_knowledge(self,
                         knowledge,
                         key='id',
                         description='description',
                         example='example',
                         escape_reserved_words=False,
                         force=False):
        """
        Upsert knowledge.

        Parameters
        ----------
        knowledge: dict or pd.DataFrame
            Knowledge data.
        key: str, optional
            Key column name.
        description: str, optional
            Description column name.
        example: str, optional
            Example column name.
        """
        embeddings = self.create_embeddings(knowledge, key, description, example, escape_reserved_words=escape_reserved_words)
        upsert = None
        if not force:
            upsert = True
        description_ = description
        if description == example:
            description_ = description + "_0"
        dataframe.create_dataframe_from_pandas(connection_context=self.connection_context,
                                               pandas_df=embeddings,
                                               table_name=self.table_name,
                                               schema=self.schema,
                                               upsert=upsert,
                                               table_structure={key: "VARCHAR(5000) PRIMARY KEY",
                                                                description_: "NCLOB",
                                                                example: "NCLOB",
                                                                "embeddings": "REAL_VECTOR({})".format(self.vector_length)},
                                                chunk_size=self.upload_chunksize,
                                                force=force)

    def query(self, input, top_n=1, embedding_function=None, distance='cosine_similarity'):
        """
        Query.
        """
        if embedding_function is None:
            embedding_function = self.embedding_function
        emb_vec = embedding_function(input)[0]
        if self.columns is None:
            self.columns = self.connection_context.table(table=self.table_name, schema=self.schema).columns
        if self.schema is None:
            schema = self.connection_context.get_current_schema()

        sql = """SELECT TOP {} "{}", {}("{}", TO_REAL_VECTOR('{}')) AS "DISTANCE" FROM "{}"."{}" ORDER BY "DISTANCE" DESC""".format(top_n, self.columns[2], distance.upper(), self.columns[3], emb_vec, schema, self.table_name)
        result = self.connection_context.sql(sql).collect()
        self.current_query_rows = result.shape[0]
        if self.current_query_rows < top_n:
            top_n = self.current_query_rows
        self.current_query_distance = result.iloc[top_n-1, 1]
        return result.iloc[top_n-1, 0]

class KnowledgeGraph(object):
    """
    Knowledge graph.
    """
    schema: str = None
    threads: int = None
    vector_length: int = None
    upload_chunksize: int = None
    embedding_batchsize: int = None
    columns: list = None
    llm: any = None
    def __init__(self, connection_context, table_name, embedding_function=None, schema=None, threads=None, upload_chunksize=50000, embedding_batchsize=None, llm=None):
        """
        Initialized HANA vector engine.

        Parameters:
        -----------
        path: str
            Path to save vectordb.
        collection_name: str
            Vectordb name.
        embedding_function: EmbeddingFunction
            Embedding function.
        threads: int, optional
            Number of threads from the client side to call the embedding service.
        upload_chunksize: int, optional
            Number of chunks for the database bulk insertion.
        embeddings_batchsize: int, optional
            Define the batchsize for each embedding service call.
        llm: any, optional
            Language model used to extract entity and relation.
        """
        self.connection_context = connection_context
        self.table_name = table_name
        self.schema = schema
        self.embedding_function = embedding_function
        if self.embedding_function is None:
            self.embedding_function = BTPProxyEmbeddingService()
        self.threads = threads
        self.upload_chunksize = upload_chunksize
        self.embedding_batchsize = embedding_batchsize
        self.llm = llm

    def create_embeddings(self,
                          knowledge,
                          entity='entity',
                          relation='relation',
                          destination='destination',
                          escape_reserved_words=False):
        """
        Create embeddings.

        Parameters
        ----------
        knowledge: dict
            Knowledge data.
        entity: str, optional
            Entity.
        relation: str, optional
            Relation.
        destination: str, optional
            Destination.
        """
        model = self.embedding_function
        knowledges = []
        t = tqdm(total=len(knowledge[entity]))
        if self.embedding_batchsize:
            if isinstance(self.threads, int):
                pool = ThreadPoolExecutor(self.threads)
                futures = []
                for chunk in range(0, len(knowledge[entity]), self.embedding_batchsize):
                    futures.append(pool.submit(_par_embeddings2, model, (knowledge[entity][chunk:chunk+self.embedding_batchsize], knowledge[relation][chunk:chunk+self.embedding_batchsize], knowledge[destination][chunk:chunk+self.embedding_batchsize]), escape_reserved_words))
                for x in as_completed(futures):
                    result = x.result()
                    knowledges = knowledges + result
                    t.update(len(result))
                pool.shutdown()
            else:
                for chunk in range(0, len(knowledge[entity]), self.embedding_batchsize):
                    result = _par_embeddings2(model, (knowledge[entity][chunk:chunk+self.embedding_batchsize],
                                                     knowledge[relation][chunk:chunk+self.embedding_batchsize],
                                                     knowledge[destination][chunk:chunk+self.embedding_batchsize]), escape_reserved_words)
                    knowledges = knowledges + result
                    t.update(len(result))
        else:
            if isinstance(self.threads, int):
                pool = ThreadPoolExecutor(self.threads)
                futures = []
                for kkey, desc, exmp in zip(knowledge[entity], knowledge[relation], knowledge[destination]):
                    futures.append(pool.submit(_par_embeddings2, model, (kkey, desc, exmp), escape_reserved_words))
                for x in as_completed(futures):
                    knowledges.append(x.result())
                    t.update(1)
                pool.shutdown()
            else:
                for kkey, desc, exmp in zip(knowledge[entity], knowledge[relation], knowledge[destination]):
                    emb_vec0 = model(kkey)
                    emb_vec1 = model(desc)
                    knowledges.append((kkey, _escape_reserved_words(desc, escape_reserved_words), _escape_reserved_words(exmp, escape_reserved_words), str(emb_vec0[0]), str(emb_vec1[0])))
                    t.update(1)
        t.close()
        if self.vector_length is None:
            self.vector_length = len(eval(knowledges[0][3]))
        relation_ = relation
        if relation == destination:
            relation_ = relation + "_0"
        return pd.DataFrame(knowledges, columns=[entity, relation_, destination, "embeddings(entity)", "embeddings(relation)"])

    def upsert_knowledge(self,
                         knowledge,
                         key='entity',
                         description='relation',
                         example='destination',
                         escape_reserved_words=False,
                         force=False):
        """
        Upsert knowledge.

        Parameters
        ----------
        knowledge: dict
            Knowledge data.
        entity: str, optional
            Entity.
        relation: str, optional
            Relation.
        destination: str, optional
            Destination.
        """
        embeddings = self.create_embeddings(knowledge, key, description, example, escape_reserved_words=escape_reserved_words)
        upsert = None
        if not force:
            upsert = True
        description_ = description
        if description == example:
            description_ = description + "_0"
        dataframe.create_dataframe_from_pandas(connection_context=self.connection_context,
                                               pandas_df=embeddings,
                                               table_name=self.table_name,
                                               schema=self.schema,
                                               upsert=upsert,
                                               table_structure={key: "VARCHAR(5000) PRIMARY KEY",
                                                                description_: "NCLOB",
                                                                example: "NCLOB",
                                                                "embeddings(entity)": "REAL_VECTOR({})".format(self.vector_length),
                                                                "embeddings(relation)": "REAL_VECTOR({})".format(self.vector_length)},
                                                chunk_size=self.upload_chunksize,
                                                force=force)

    def set_llm(self, llm):
        """
        Set llm.

        Parameters
        ----------
        llm: any
            Large language model.
        """
        self.llm = llm

    def find_target(self, entity, relation, top_n=1, distance='cosine_similarity'):
        """
        Find target.

        Parameters
        ----------
        entity: str
            Entity.
        relation: str
            Relation.
        top_n: int, optional
            Top n.
        distance: str, optional
            Distance.
        """
        schema = self.schema
        if self.columns is None:
            self.columns = self.connection_context.table(table=self.table_name, schema=self.schema).columns
        if schema is None:
            schema = self.connection_context.get_current_schema()
        return self.connection_context.sql("""
SELECT TOP {0} "{1}",
       {2}("{3}", TO_REAL_VECTOR('{4}')) AS "COS_SIM_0",
       {2}("{5}", TO_REAL_VECTOR('{6}')) AS "COS_SIM_1"
       FROM "{7}"."{8}" ORDER BY "COS_SIM_0" DESC, "COS_SIM_1" DESC
""".format(top_n,
           self.columns[2],
           distance.upper(),
           self.columns[3],
           str(self.embedding_function(entity)[0]),
           self.columns[4],
           str(self.embedding_function(relation)[0]),
           schema,
           self.table_name)).collect().iloc[top_n-1, 0]

    def query(self, input, top_n=1, distance='cosine_similarity'):
        """
        Query.

        Parameters
        ----------
        input: str
            Input.
        top_n: int, optional
            Top n.
        distance: str, optional
            Distance.
        """
        if self.llm is None:
            raise ValueError("llm is not defined.")
        entity, relation = extract_entity_relation_by_llm(input, self.llm)
        return self.find_target(entity, relation, top_n=top_n, distance=distance)
