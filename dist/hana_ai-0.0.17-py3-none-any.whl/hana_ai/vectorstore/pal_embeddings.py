"""
Embeddings inside HANA
"""

#pylint: disable=redefined-builtin

import uuid
import logging


try:
    import pyodbc
except ImportError as error:
    pass
from hdbcli import dbapi
from hana_ml.dataframe import quotename
from hana_ml.algorithms.pal.pal_base import (
    PALBase,
    ParameterTable,
    try_drop
)

from hana_ai.vectorstore.embedding_service import LocalEmbeddingModel

logger = logging.getLogger(__name__)#pylint: disable=invalid-name

class PALEmbeddings(PALBase):
    """
    PAL embeddings.

    Parameters:
    -----------
    url: str
        URL of the PAL embeddings.
    """
    def __init__(self, url=None, batch_size=3):
        super(PALEmbeddings, self).__init__()
        self.url = url
        self.batch_size = batch_size
        self.result_ = None
        self.connection_context = None
        self.embedding_col = None
        self.target = None

    def predict(self, data, key, target, thread_ratio=None, thread_number=None):
        """
        Predict the embeddings.

        Parameters:
        -----------
        data: DataFrame
            Data.
        key: str
            Key.
        target: str
            Target.
        thread_ratio: float
            Thread ratio.
        thread_number: int
            Thread number.
        """
        conn = data.connection_context
        self.connection_context = conn
        self.target = target
        unique_id = str(uuid.uuid1()).replace('-', '_').upper()
        embeddings_tbl = '#PAL_EMBEDDINGS_RESULT_TBL_{}_{}'.format(0, unique_id)
        outputs = [embeddings_tbl]
        param_rows = [("URL", None, None, self.url),
                      ("BATCH_SIZE", self.batch_size, None, None),
                      ("THREAD_RATIO", None, thread_ratio, None),
                      ("THREAD_NUMBER", thread_number, None, None)]
        data_ = data.select([key, target])
        try:
            self._call_pal_auto(conn,
                                'PAL_TEXTEMBEDDING',
                                data_,
                                ParameterTable().with_data(param_rows),
                                *outputs)
        except dbapi.Error as db_err:
            msg = str(conn.hana_version())
            logger.exception("HANA version: %s. %s", msg, str(db_err))
            try_drop(conn, outputs)
            raise
        except pyodbc.Error as db_err:
            msg = str(conn.hana_version())
            logger.exception("HANA version: %s. %s", msg, str(db_err.args[1]))
            try_drop(conn, outputs)
            raise
        result = conn.table(embeddings_tbl)
        self.embedding_col = result.columns[1]
        processed_result = conn.sql("SELECT {0}, {1} FROM ({2})".format(quotename(result.columns[0]), quotename(result.columns[1]), result.select_statement))
        self.result_ = data.set_index(key).join(processed_result.set_index(processed_result.columns[0]))
        return self.result_

    def query(self, input, top_n=1, embedding_function=None, answer_column=None, distance='cosine_similarity'):
        """
        Query.

        Parameters:
        -----------
        input: str
            Input.
        top_n: int
            Top N.
        embedding_function: Embeddings
            Embedding function.
        answer_column: str
            Answer column.
        distance: str
            Distance.
        """
        if embedding_function is None:
            embedding_function = LocalEmbeddingModel()
        emb_vec = embedding_function(input)[0]
        if answer_column is None:
            answer_column = self.target

        sql = """SELECT TOP {0} "{1}", {5}("{2}", TO_REAL_VECTOR('{3}')) AS "DISTANCE" FROM ({4}) ORDER BY "DISTANCE" DESC""".format(top_n, answer_column, self.embedding_col, emb_vec, self.result_.select_statement, distance.upper())
        logger.info("Query: %s", sql)
        return self.connection_context.sql(sql).collect().iloc[top_n-1, 0]
