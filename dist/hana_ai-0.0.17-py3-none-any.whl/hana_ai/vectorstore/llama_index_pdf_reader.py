"""
Llama index pdf reader
"""

#pylint: disable=redefined-builtin

import logging
from llama_index.core.node_parser import SentenceWindowNodeParser, SentenceSplitter
from llama_index.core import SimpleDirectoryReader, VectorStoreIndex, StorageContext, load_index_from_storage, Settings
from llama_index.core.postprocessor import MetadataReplacementPostProcessor

logger = logging.getLogger(__name__) #pylint: disable=invalid-name

class LlamaIndexPdfReader(object):
    """
    Create vector database from pdf files.

    Parameters:
    -----------
    llm: LLM
        LLM model.
    embedding_function: EmbeddingFunction
        Embedding function.
    window_size: int
        Window size.
    """
    documents: any = None
    llm: any
    embedding_function: any
    text_splitter: any
    node_parser: any
    sentence_index: any = None
    nodes: any
    query_engine: any = None
    def __init__(self, llm, embedding_function, window_size=3):
        self.text_splitter = SentenceSplitter()
        self.llm = llm
        self.embedding_function = embedding_function
        Settings.llm = self.llm
        Settings.embed_model = self.embedding_function
        Settings.text_splitter = self.text_splitter
        self.node_parser = SentenceWindowNodeParser.from_defaults(
            window_size=window_size,
            window_metadata_key="window",
            original_text_metadata_key="original_text",
        )

    def create_sentence_index(self, path, persist_path=None, show_progress=False):
        """
        Read pdf file and create vector database.

        Parameters:
        -----------
        path: str
            Path to pdf file.
        """
        self.documents = SimpleDirectoryReader(input_files=[path]).load_data()
        self.nodes = self.node_parser.get_nodes_from_documents(self.documents)
        self.sentence_index = VectorStoreIndex(self.nodes, show_progress=show_progress)
        if persist_path:
            self.sentence_index.storage_context.persist(persist_dir=persist_path)

    def load_from_files(self, file_path):
        """
        Load from vector store.
        """

        # rebuild storage context
        storage_context = StorageContext.from_defaults(persist_dir=file_path)

        # load index
        self.sentence_index = load_index_from_storage(storage_context)

    def query(self, input, top_n=1):
        """
        Query.

        Parameters:
        -----------
        input: str
            Input.
        top_n: int
            Top N.
        """
        if self.sentence_index is None:
            raise ValueError("Index not created")
        if self.query_engine is None:
            self.query_engine = self.sentence_index.as_query_engine(
                similarity_top_k=top_n,
                # the target key defaults to `window` to match the node_parser's default
                node_postprocessors=[
                    MetadataReplacementPostProcessor(target_metadata_key="window")
                ],
            )
        self.query_engine.similarity_top_k = top_n
        return self.query_engine.query(input).response
