"""
This module includes embedding service from local embedding model or from llm_commons
"""

# pylint: disable=redefined-builtin
# pylint: disable=unnecessary-dunder-call
# pylint: disable=unused-argument

from typing import List
import json
import requests
try:
    from llm_commons.langchain.proxy import init_embedding_model as btp_embedding_model
except:
    pass
try:
    from gen_ai_hub.proxy.langchain import init_embedding_model as gen_ai_hub_embedding_model
except:
    pass
from langchain.embeddings.base import Embeddings

class LocalEmbeddingModel(Embeddings):
    """
    Local embedding model.

    Parameters:
    -----------
    url: str
        URL of the local embedding model.
    """
    url: str
    def __init__(self, url='http://ls3085.wdf.sap.corp:7880/embedding'):
        """
        Init local embedding model.
        """
        self.url = url

    def __call__(self, input):
        if isinstance(input, str):
            input = [input]
        x = requests.post(self.url, data=json.dumps(input), headers={"accept": "application/json", "Content-Type": "application/json"}, timeout=60)
        output = json.loads(x.text)["output"]
        if len(output) == 1:
            return [output[0]]
        return output

    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        """
        Embed multiple documents.
        """
        return self.__call__(texts)

    def embed_query(self, text: str) -> List[float]:
        """
        Embed a single query.
        """
        return self.__call__(text)[0]

    def get_text_embedding_batch(self, texts: List[str], show_progress=False, **kwargs):
        """
        Get text embedding batch.
        """
        return self.embed_documents(texts)

class GenAIHubEmbeddingService(Embeddings):
    """
    A class representing the embedding service for GenAIHub.

    Parameters:
    -----------
    deployment_id: str
        Deployment ID.
    """
    model: Embeddings
    def __init__(self, deployment_id='text-embedding-ada-002', **kwargs):
        """
        Init embedding service from llm_commons.
        """
        self.model = gen_ai_hub_embedding_model(deployment_id, **kwargs)

    def __call__(self, input):
        result = []
        if isinstance(input, list):
            result = self.model.embed_documents(input)
        else:
            result.append(self.model.embed_query(input))
        return result

    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        """
        Embed multiple documents.
        """
        return self.model.embed_documents(texts)

    def embed_query(self, text: str) -> List[float]:
        """
        Embed a single query.
        """
        return self.model.embed_query(text)

    def get_text_embedding_batch(self, texts: List[str], show_progress=False, **kwargs):
        """
        Get text embedding batch.
        """
        return self.embed_documents(texts)

class BTPProxyEmbeddingService(Embeddings):
    """
    BTP proxy embedding service.

    Parameters:
    -----------
    deployment_id: str
        Deployment ID.
    """
    model: Embeddings
    def __init__(self, deployment_id='text-embedding-ada-002-v2', **kwargs):
        """
        Init embedding service from llm_commons.
        """
        self.model = btp_embedding_model(deployment_id, **kwargs)

    def __call__(self, input):
        result = []
        if isinstance(input, list):
            result = self.model.embed_documents(input)
        else:
            result.append(self.model.embed_query(input))
        return result

    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        """
        Embed multiple documents.
        """
        return self.model.embed_documents(texts)

    def embed_query(self, text: str) -> List[float]:
        """
        Embed a single query.
        """
        return self.model.embed_query(text)

    def get_text_embedding_batch(self, texts: List[str], show_progress=False, **kwargs):
        """
        Get text embedding batch.
        """
        return self.embed_documents(texts)
